import * as glue from "@hapi/glue";
import { sequelize } from "./mobile/models/model";
const manifest = {
  server: {
    port: process.env.PORT || 4000,
    host: "localhost",
  },
  register: {
    plugins: [
      { plugin: "./mobile" },
      { plugin: require("@hapi/inert") },
      { plugin: require("hapi-swagger") },
      { plugin: require("@hapi/vision") },
    ],
  },
};
async function startServer() {
  const options = {
    relativeTo: __dirname,
  };
  const server = await glue.compose(manifest, options);
  await server.start();
  console.log(`Hapi server started at ${server.info.uri}`);
  try {
    sequelize.authenticate();
    console.log("Connected to database");
  } catch (error) {
    console.log("Could not connect to database", error);
  }
}
startServer();
