import * as hapi from "@hapi/hapi";
import joi from "joi";
import { MobileService } from "../services/services";
export class MobileController {
  private mobileService: MobileService;
  constructor() {
    this.mobileService = new MobileService();
  }
  //Get all listed products
  public getAllProducts(): hapi.RouteOptions {
    return {
      handler: async (request: any, h: hapi.ResponseToolkit) => {
        return await this.mobileService.getAllProducts();
      },
      tags: ["api", "GET", "Mobile", "Info"],
      description: "Get all mobiles info",
    };
  }
  //Get product info by ProductID
  public getProductInfo(): hapi.RouteOptions {
    return {
      handler: async (request: any, h: hapi.ResponseToolkit) => {
        let productId: number = request.params.productId;
        return await this.mobileService.getProductInfo(productId);
      },
      tags: ["api", "GET", "Mobile", "Info"],
      description: "Get a mobiles info by it's ID",
      validate: {
        params: joi.object({
          productId: joi.number().integer().positive().required(),
        }),
      },
    };
  }

  //add a new product. Multipart/form-data
  public addProduct(): hapi.RouteOptions {
    return {
      handler: async (request: any, h: hapi.ResponseToolkit) => {
        const formFields = request.payload;
        return await this.mobileService.addProduct(formFields);
      },
      payload: {
        parse: true,
        allow: "multipart/form-data",
        multipart: {
          output: "file",
        },
      },
      tags: ["api", "POST", "Mobile", "Add"],
      description: "Add a new product",
      validate: {
        payload: joi.object({
          model: joi.string().required(),
          features: joi.string().required(),
          price: joi.number().positive().required(),
          stock: joi.number().integer().positive().required(),
          companyName: joi.string().required(),
          titleimg: joi.object().required(),
        }),
      },
    };
  }
  //get all listed companies.
  public getAllCompany() {
    return {
      handler: async (request: any, h: hapi.ResponseToolkit) => {
        return await this.mobileService.getAllCompany();
      },
      tags: ["api", "GET", "Company", "All"],
      description: "Get all company",
    };
  }
  //Register a new user
  public registerUser() {
    return {
      handler: async (request: any, h: hapi.ResponseToolkit) => {
        const userData = request.payload;
        return await this.mobileService.registerUser(userData);
      },
      tags: ["api", "POST", "User", "Register"],
      description: "User registration",
      validate: {
        payload: joi.object({
          firstName: joi.string().required().description("First Name of user"),
          lastName: joi.string().required().description("Last Name of user"),
          email: joi.string().email().required().description("Email of user"),
          role: joi
            .string()
            .valid("user", "admin")
            .required()
            .description("User role"),
          password: joi.string().required().min(8).description("User password"),
          submit: joi.boolean(),
        }),
      },
    };
  }
  public resetPassword() {
    return {
      handler: async (request: any, h: hapi.ResponseToolkit) => {
        const formData = request.payload;
        return await this.mobileService.resetPassword(formData);
      },
      tags: ["api", "PUT", "User", "Forget password"],
      description: "Reset user password ",
      validate: {
        payload: joi.object({
          email: joi.string().email().required().description("Email of user"),
          password: joi.string().required().min(8).description("User password"),
          submit: joi.boolean(),
        }),
      },
    };
  }
  //User login
  public loginUser() {
    return {
      handler: async (request: any, h: hapi.ResponseToolkit) => {
        const userData = request.payload;
        return await this.mobileService.loginUser(userData);
      },
      tags: ["api", "POST", "User", "Login"],
      description: "User Login",
      validate: {
        payload: joi.object({
          email: joi.string().email().required(),
          password: joi.string().required(),
          submit: joi.boolean(),
        }),
      },
    };
  }
  //Update existing product
  public updateProduct() {
    return {
      handler: async (request: any, h: hapi.ResponseToolkit) => {
        const productData = request.payload;
        return await this.mobileService.updateProduct(productData);
      },
      payload: {
        parse: true,
        allow: "multipart/form-data",
        multipart: {
          output: "file",
        },
      },
      tags: ["api", "PUT", "Mobile", "Update"],
      description: "Update a product",
      validate: {
        payload: joi.object({
          id: joi.number().integer().positive().required(),
          model: joi.string().required(),
          features: joi.string().required(),
          price: joi.number().positive().required(),
          stock: joi.number().integer().positive().required(),
          titleimg: joi.object().required(),
        }),
      },
    };
  }
  //Delete a product
  public deleteProduct() {
    return {
      handler: async (request: any, h: hapi.ResponseToolkit) => {
        let productId: number = request.params.productId;
        return await this.mobileService.deleteProduct(productId);
      },
      tags: ["api", "DELETE", "Product"],
      description: "Delete a product",
      validate: {
        params: joi.object({
          productId: joi.number().integer().positive().required(),
        }),
      },
    };
  }
  //Returns a product image
  public getImage() {
    return {
      handler: async (request: any, h: hapi.ResponseToolkit) => {
        let productId: number = request.params.productId;
        const imagePath = await this.mobileService.getImagePathByProductId(
          productId
        );
        return h.file(imagePath);
      },
      tags: ["api", "GET", "Image"],
      description: "Get image of product",
      validate: {
        params: joi.object({
          productId: joi.number().integer().positive().required(),
        }),
      },
    };
  }
  //a function to buy product
  public buyProduct() {
    return {
      handler: async (request: any, h: hapi.ResponseToolkit) => {
        const data = request.payload;
        return await this.mobileService.buyProduct(data);
      },
      payload: {
        parse: true,
        allow: "multipart/form-data",
        multipart: {
          output: "file",
        },
      },
      tags: ["api", "POST", "Product", "Buy"],
      description: "Buy product",
      validate: {
        payload: joi.object({
          productId: joi.number().integer().positive().required(),
          userId: joi.number().integer().positive().required(),
          quantity: joi.number().integer().positive().required(),
        }),
      },
    };
  }
  //a function to add products to cart
  public addToCart() {
    return {
      handler: async (request: any, h: hapi.ResponseToolkit) => {
        const data = request.payload;
        return await this.mobileService.addToCart(data);
      },
      payload: {
        parse: true,
        allow: "multipart/form-data",
        multipart: {
          output: "file",
        },
      },
      tags: ["api", "POST", "Product", "Cart"],
      description: "Add product to cart",
      validate: {
        payload: joi.object({
          productId: joi.number().integer().positive().required(),
          userId: joi.number().integer().positive().required(),
          quantity: joi.number().integer().positive().required(),
        }),
      },
    };
  }
  //remove a product from cart
  public removeFromCart() {
    return {
      handler: async (request: any, h: hapi.ResponseToolkit) => {
        const cartId: number = request.params.cartId;
        return await this.mobileService.removeFromCart(cartId);
      },
      tags: ["api", "GET", "Product", "Cart"],
      description: "Remove product from cart",
      validate: {
        params: joi.object({
          cartId: joi.number().integer().positive().required(),
        }),
      },
    };
  }
  //get cart of a user from userId
  public getCart() {
    return {
      handler: async (request: any, h: hapi.ResponseToolkit) => {
        const userId: number = request.params.userId;
        return await this.mobileService.getCart(userId);
      },
      tags: ["api", "GET", "Product", "Cart"],
      description: "Get cart of a user",
      validate: {
        params: joi.object({
          userId: joi.number().integer().positive().required(),
        }),
      },
    };
  }
  //function to place order of all items in a cart
  public placeOrder() {
    return {
      handler: async (request: any, h: hapi.ResponseToolkit) => {
        const userId: number = request.payload.userId;
        return await this.mobileService.placeOrder(userId);
      },
      payload: {
        parse: true,
        allow: "multipart/form-data",
        multipart: {
          output: "file",
        },
      },
      tags: ["api", "POST", "Product", "Buy"],
      description: "Buy all products from cart",
      validate: {
        payload: joi.object({
          userId: joi.number().integer().positive().required(),
        }),
      },
    };
  }
  //get all previous orders of all users
  public getAllPurchased() {
    return {
      handler: async (request: any, h: hapi.ResponseToolkit) => {
        return await this.mobileService.getAllPurchased();
      },
      tags: ["api", "GET", "Purchased", "All"],
      description: "Get all purchased orders.",
    };
  }
  //get all previous orders of a users
  public getAllPurchasedUser() {
    return {
      handler: async (request: any, h: hapi.ResponseToolkit) => {
        const userId: number = request.params.userId;
        return await this.mobileService.getAllPurchasedUser(userId);
      },
      tags: ["api", "GET", "Purchased", "All"],
      description: "Get all purchased orders.",
      validate: {
        params: joi.object({
          userId: joi.number().integer().positive().required(),
        }),
      },
    };
  }
  //Get all registered users
  public getAllUser() {
    return {
      handler: async (request: any, h: hapi.ResponseToolkit) => {
        return await this.mobileService.getAllUsers();
      },
      tags: ["api", "GET", "Users", "All"],
      description: "Get all users.",
    };
  }
  //User log out
  public userLogOut() {
    return {
      handler: async (request: any, h: hapi.ResponseToolkit) => {
        const userId: number = request.payload.userId;
        return await this.mobileService.userLogOut(userId);
      },
      payload: {
        parse: true,
        allow: "multipart/form-data",
        multipart: {
          output: "file",
        },
      },
      tags: ["api", "POST", "User", "Log out"],
      description: "Log out user.",
      validate: {
        payload: joi.object({
          userId: joi.number().integer().positive().required(),
        }),
      },
    };
  }
  //search products using keyword
  public searchProduct() {
    return {
      handler: async (request: any, h: hapi.ResponseToolkit) => {
        let queryKeyword: string = request.query.keyword;
        return await this.mobileService.searchProduct(queryKeyword);
      },
      tags: ["api", "GET", "Product"],
      description: "Get search result from products",
      validate: {
        query: joi.object({
          keyword: joi.string().max(20).required(),
        }),
      },
    };
  }
}
