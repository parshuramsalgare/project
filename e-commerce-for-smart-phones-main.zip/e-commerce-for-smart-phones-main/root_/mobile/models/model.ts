import { Sequelize, DataTypes } from "sequelize";
export const sequelize = new Sequelize("mobiles", "postgres", "1234", {
  host: "localhost",
  dialect: "postgres",
});
export const User = sequelize.define("user", {
  firstName: {
    type: DataTypes.STRING,
    allowNull: false,
  },
  lastName: {
    type: DataTypes.STRING,
    allowNull: false,
  },
  email: {
    type: DataTypes.STRING,
    allowNull: false,
    unique: true,
    validate: {
      isEmail: true,
    },
  },
  role: {
    type: DataTypes.STRING,
    allowNull: false,
  },
  password: {
    type: DataTypes.STRING,
    allowNull: false,
  },
  status: {
    type: DataTypes.STRING,
  },
});
export const Product = sequelize.define("product", {
  model: {
    type: DataTypes.STRING,
    allowNull: false,
  },
  features: {
    type: DataTypes.STRING,
  },
  price: {
    type: DataTypes.FLOAT,
    allowNull: false,
  },
  stock: {
    type: DataTypes.INTEGER,
    allowNull: false,
  },
  imagePath: {
    type: DataTypes.STRING,
    allowNull: false,
    unique: true,
  },
  fileapi: {
    type: DataTypes.STRING,
  },
  companyName: {
    type: DataTypes.STRING,
  },
});
export const Purchase = sequelize.define("purchase", {
  details: { type: DataTypes.STRING },
  quantity: {
    type: DataTypes.INTEGER,
    allowNull: false,
  },
  cost: {
    type: DataTypes.FLOAT,
    allowNull: false,
  },
  createdAt: {
    type: DataTypes.DATE,
    get() {
      const rawValue = this.getDataValue("createdAt");
      const seconds = Date.parse(rawValue);
      const date = new Date(seconds);
      return date.toString().substring(0, 24);
    },
  },
});
export const Cart = sequelize.define("cart", {
  quantity: {
    type: DataTypes.INTEGER,
    allowNull: false,
  },
  cost: {
    type: DataTypes.FLOAT,
    allowNull: false,
  },
});
User.hasMany(Purchase);
Purchase.belongsTo(User);
Product.hasMany(Purchase);
Purchase.belongsTo(Product);
Product.hasMany(Cart);
Cart.belongsTo(Product);
User.hasMany(Cart);
Cart.belongsTo(User);
