import * as hapi from "@hapi/hapi";
import { routes } from "./routes/route";

exports.plugin = {
  register: async (server: hapi.Server, options: any) => {
    try {
      routes(server);
      console.log("Mobiles plugin registered successfully");
    } catch (error) {
      console.log("Error occured while registering mobile plugin");
    }
  },
  name: "Mobiles plugin",
  version: "1.0.0",
};
