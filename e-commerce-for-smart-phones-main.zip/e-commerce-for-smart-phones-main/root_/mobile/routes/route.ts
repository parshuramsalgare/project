import * as hapi from "@hapi/hapi";
import { MobileController } from "../controller/controller";
export function routes(server: hapi.Server) {
  const mobileController = new MobileController();
  server.route([
    {
      method: "POST",
      path: "/api/user/register",
      options: mobileController.registerUser(),
    },
    {
      method: "PUT",
      path: "/api/user/resetpassword",
      options: mobileController.resetPassword(),
    },
    {
      method: "POST",
      path: "/api/login",
      options: mobileController.loginUser(),
    },
    {
      method: "GET",
      path: "/api/get/all/product",
      options: mobileController.getAllProducts(),
    },
    {
      method: "GET",
      path: "/api/get/product/{productId}",
      options: mobileController.getProductInfo(),
    },

    {
      method: "POST",
      path: "/api/add/product",
      options: mobileController.addProduct(),
    },
    {
      method: "PUT",
      path: "/api/update/product",
      options: mobileController.updateProduct(),
    },
    {
      method: "GET",
      path: "/api/get/all/company",
      options: mobileController.getAllCompany(),
    },
    {
      method: "DELETE",
      path: "/api/delete/product/{productId}",
      options: mobileController.deleteProduct(),
    },
    {
      method: "GET",
      path: "/api/get/image/{productId}",
      options: mobileController.getImage(),
    },
    {
      method: "POST",
      path: "/api/product/buy",
      options: mobileController.buyProduct(),
    },
    {
      method: "POST",
      path: "/api/product/addtocart",
      options: mobileController.addToCart(),
    },
    {
      method: "DELETE",
      path: "/api/product/removefromcart/{cartId}",
      options: mobileController.removeFromCart(),
    },
    {
      method: "GET",
      path: "/api/product/cart/get/{userId}",
      options: mobileController.getCart(),
    },
    {
      method: "POST",
      path: "/api/product/placeorder",
      options: mobileController.placeOrder(),
    },
    {
      method: "GET",
      path: "/api/get/all/purchased",
      options: mobileController.getAllPurchased(),
    },
    {
      method: "GET",
      path: "/api/get/all/purchased/{userId}",
      options: mobileController.getAllPurchasedUser(),
    },
    {
      method: "GET",
      path: "/api/get/all/user",
      options: mobileController.getAllUser(),
    },
    {
      method: "POST",
      path: "/api/logout",
      options: mobileController.userLogOut(),
    },
    {
      method: "GET",
      path: "/api/search",
      options: mobileController.searchProduct(),
    },
  ]);
}
