import * as fs from "fs";
import { Op } from "sequelize";
import { sequelize, User, Product, Purchase, Cart } from "../models/model";
interface typeBuyProduct {
  productId: number;
  userId: number;
  quantity: number;
}
export class MobileService {
  //function returns all products information along with company information
  private successResponce: string = JSON.stringify({ message: "success" });
  private errorResponce: string = JSON.stringify({ message: "error" });
  public async getAllProducts() {
    const allProducts = await Product.findAll({
      attributes: { exclude: ["imagePath"] },
    });
    if (allProducts.length !== 0) {
      const productsJSON = JSON.stringify(allProducts, null, 2);
      return productsJSON;
    } else {
      return JSON.stringify({ status: "Empty" });
    }
  }
  //Get product info by productID
  public async getProductInfo(productID: number) {
    const productInfo = await Product.findOne({
      attributes: { exclude: ["imagePath"] },
      where: { id: productID },
    });
    if (productInfo) {
      return JSON.stringify(productInfo, null, 2);
    } else {
      return JSON.stringify({ status: "Not found" });
    }
  }

  //adds new product to database
  public async addProduct(form_fields: any) {
    try {
      let newPath = __dirname.slice(0, -15);
      newPath += `images/${Date.now() + form_fields.titleimg.filename}`;
      const oldPath = form_fields.titleimg.path;
      fs.rename(oldPath, newPath, function (err) {
        if (err) throw err;
      });
      const newProduct: any = await Product.create({
        model: form_fields.model,
        features: form_fields.features,
        price: form_fields.price,
        stock: form_fields.stock,
        companyName: form_fields.companyName,
        imagePath: newPath,
      });
      await Product.update(
        { fileapi: `http://localhost:4200/api/get/image/${newProduct.id}` },
        { where: { id: newProduct.id } }
      );
      return this.successResponce;
    } catch (error) {
      console.error(error);
      return this.errorResponce;
    }
  }
  //returns information of all companies
  public async getAllCompany() {
    try {
      const allCompany = await Product.findAll({
        attributes: [
          [sequelize.fn("DISTINCT", sequelize.col("companyName")), "company"],
        ],
        order: sequelize.literal("company ASC"),
      });
      return JSON.stringify(allCompany, null, 2);
    } catch (error) {
      console.error(error);
      return this.errorResponce;
    }
  }
  //function to register a new user
  public async registerUser(userData: any) {
    try {
      const exist = await User.findOne({ where: { email: userData.email } });
      if (exist) throw "Already exist";
      if (userData.role === "admin") {
        const [noOfAdmin]: any = await User.findAll({
          attributes: [
            [sequelize.fn("COUNT", sequelize.col("role")), "no_of_admin"],
          ],
          where: { role: "admin" },
          raw: true,
        });
        if (noOfAdmin.no_of_admin === "2") throw "Cannot register as admin";
      }
      await User.create({
        firstName: userData.firstName,
        lastName: userData.lastName,
        email: userData.email,
        role: userData.role,
        password: userData.password,
      });
      return this.successResponce;
    } catch (error) {
      return JSON.stringify({ message: "error", error: error });
    }
  }
  public async resetPassword(formData: any) {
    try {
      const ifExist = await User.findOne({
        where: { email: formData.email },
        raw: true,
      });
      if (!ifExist) return JSON.stringify({ message: "not registered" });
      await User.update(
        { password: formData.password },
        { where: { email: formData.email } }
      );
      return this.successResponce;
    } catch (error) {
      console.error(error);
      return this.errorResponce;
    }
  }
  //function to login user into the system
  public async loginUser(loginData: any) {
    try {
      const result: any = await User.findOne({
        where: {
          email: loginData.email,
          password: loginData.password,
        },
      });
      if (result) {
        User.update({ status: "active" }, { where: { id: result.id } });
        return JSON.stringify({
          status: "success",
          userId: result.id,
          role: result.role,
          firstName: result.firstName,
        });
      } else return JSON.stringify({ status: "failed" });
    } catch (error) {
      console.error(error);
      return JSON.stringify({ message: "error" });
    }
  }
  //function to update an existing product
  public async updateProduct(formData: any) {
    try {
      const oldImg = await this.getImagePathByProductId(formData.id);
      fs.unlink(oldImg, (error) => {
        if (error) throw error;
      });
      let newPath = __dirname.slice(0, -15);
      newPath += `images/${Date.now() + formData.titleimg.filename}`;
      const oldPath = formData.titleimg.path;
      fs.rename(oldPath, newPath, function (error) {
        if (error) throw error;
      });
      const result = await Product.update(
        {
          model: formData.model,
          features: formData.features,
          price: formData.price,
          stock: formData.stock,
          imagePath: newPath,
        },
        { where: { id: formData.id } }
      );
      if (result[0] !== 0) {
        await Cart.update(
          { cost: sequelize.literal(`quantity * ${formData.price}`) },
          { where: { productId: formData.id } }
        );
        return JSON.stringify({ message: "update success" });
      } else throw "error";
    } catch (err) {
      console.error(err);
      return this.errorResponce;
    }
  }
  //function to delete a product
  public async deleteProduct(productId: number) {
    try {
      const imgPath = await this.getImagePathByProductId(productId);
      if (imgPath) {
        fs.unlink(imgPath, (error) => {
          if (error) {
            throw error;
          }
        });
      }
      await Cart.destroy({ where: { productId: productId } });
      await Product.destroy({ where: { id: productId } });
      return this.successResponce;
    } catch (error) {
      console.error(error);
      return this.errorResponce;
    }
  }
  //function to buy a product
  public async buyProduct(data: typeBuyProduct) {
    try {
      const ifLoggedIn = await this.userAuthentication(data.userId);
      if (ifLoggedIn.status !== "active")
        return JSON.stringify({ message: "not logged in" });
      const productInfo = await Product.findOne({
        where: { id: data.productId },
      });
      if (productInfo === null) return JSON.stringify({ message: "Not found" });
      await this.addProductToPurchase(data);
      return this.successResponce;
    } catch (error) {
      console.error(error);
      return this.errorResponce;
    }
  }
  //function to add products to cart
  public async addToCart(data: typeBuyProduct) {
    try {
      const ifLoggedIn = await this.userAuthentication(data.userId);
      if (ifLoggedIn.status !== "active")
        return JSON.stringify({ message: "not logged in" });
      const productData: any = await Product.findOne({
        attributes: ["price", "stock"],
        where: { id: data.productId },
        raw: true,
      });
      if (productData === null) return JSON.stringify({ message: "Not found" });
      if (productData.stock < data.quantity)
        return JSON.stringify({ message: "Insufficient stock" });
      const ifExist = await Cart.findOne({
        where: {
          productId: data.productId,
          userId: data.userId,
        },
        raw: true,
      });
      if (ifExist) {
        await Cart.update(
          {
            quantity: sequelize.literal(`quantity + ${data.quantity}`),
            cost: sequelize.literal(
              `cost + ${data.quantity * productData.price}`
            ),
          },
          {
            where: {
              productId: data.productId,
              userId: data.userId,
            },
          }
        );
        return this.successResponce;
      } else {
        await Cart.create({
          quantity: data.quantity,
          cost: sequelize.literal(`${productData.price} * ${data.quantity}`),
          userId: data.userId,
          productId: data.productId,
        });
        return this.successResponce;
      }
    } catch (error) {
      console.error(error);
      return this.errorResponce;
    }
  }
  //Remove product from cart
  public async removeFromCart(cartId: number) {
    try {
      const result = await Cart.destroy({ where: { id: cartId } });
      if (result) return this.successResponce;
      else throw "error";
    } catch (error) {
      console.error(error);
      return this.errorResponce;
    }
  }
  //fetch all items in cart of a user
  public async getCart(user_Id: number) {
    try {
      const ifLoggedIn = await this.userAuthentication(user_Id);
      if (ifLoggedIn.status !== "active")
        return JSON.stringify({ message: "not logged in" });
      const cartData = await Cart.findAll({
        where: { userId: user_Id },
        include: Product,
      });
      if (cartData.length === 0)
        return JSON.stringify({ message: "Empty cart" });
      //Calculating sum of items in the cart
      const totalCost = await Cart.findAll({
        attributes: [[sequelize.fn("SUM", sequelize.col("cost")), "total"]],
        where: { userId: user_Id },
        raw: true,
      });
      return JSON.stringify({ cartData, totalCost }, null, 2);
    } catch (error) {
      console.error(error);
      return this.errorResponce;
    }
  }
  //Buy all products in the cart
  public async placeOrder(paraUserId: number) {
    try {
      const productsInCart = await Cart.findAll({
        where: { userId: paraUserId },
        raw: true,
      });
      if (productsInCart.length === 0)
        return JSON.stringify({ message: "Empty cart" });
      //calling function for all elements in the cart
      productsInCart.forEach(async (element: any) => {
        await this.addProductToPurchase(element);
      });
      await Cart.destroy({ where: { userId: paraUserId } });
      return this.successResponce;
    } catch (error) {
      console.error(error);
      return this.errorResponce;
    }
  }
  //get list of all purchased products along with details
  public async getAllPurchased() {
    try {
      const result = await Purchase.findAll({
        attributes: { exclude: ["updatedAt"] },
        include: [Product, User],
      });
      return JSON.stringify(result, null, 2);
    } catch (error) {
      console.error(error);
      return this.errorResponce;
    }
  }
  //get list of all purchased of a user products along with details
  public async getAllPurchasedUser(userId_para: number) {
    const result = await Purchase.findAll({
      attributes: { exclude: ["updatedAt"] },
      where: { userId: userId_para },
    });
    return JSON.stringify(result, null, 2);
  }
  //get list of all users
  public async getAllUsers() {
    const result = await User.findAll({
      attributes: ["id", "firstName", "lastName", "email"],
      where: { role: "user" },
    });
    return JSON.stringify(result, null, 2);
  }
  //function to log out user
  public async userLogOut(userId: number) {
    try {
      await User.update({ status: null }, { where: { id: userId } });
      return this.successResponce;
    } catch (error) {
      console.error(error);
      return this.errorResponce;
    }
  }
  //function returns image path by product id
  public async getImagePathByProductId(productId: number) {
    const result: any = await Product.findOne({
      attributes: ["imagePath"],
      where: { id: productId },
      raw: true,
    });
    return result.imagePath;
  }
  //function adds product to purchase table and updates stock
  public async addProductToPurchase(data: typeBuyProduct) {
    try {
      //getting price and stock of product
      const productData: any = await Product.findOne({
        attributes: ["model", "price", "stock", "companyName"],
        where: { id: data.productId },
        raw: true,
      });
      //checking availability of stock
      if (productData.stock < data.quantity)
        return JSON.stringify({ message: "Insufficient stock" });
      await Purchase.create({
        quantity: data.quantity,
        cost: sequelize.literal(`${productData.price} * ${data.quantity}`),
        details: productData.companyName + " " + productData.model,
        userId: data.userId,
        productId: data.productId,
      });
      //updating the stock
      await Product.update(
        { stock: sequelize.literal(`stock - ${data.quantity}`) },
        { where: { id: data.productId } }
      );
    } catch (error) {
      console.error(error);
    }
  }
  //function to check if user is logged in or not
  public async userAuthentication(userId: number) {
    const ifLoggedIn: any = await User.findOne({
      attributes: ["status"],
      where: { id: userId },
      raw: true,
    });
    return ifLoggedIn;
  }
  // function to search products using query
  public async searchProduct(query: string) {
    try {
      const result = await Product.findAll({
        attributes: { exclude: ["imagePath"] },
        where: {
          [Op.or]: [
            { model: { [Op.iLike]: "%" + query + "%" } },
            { companyName: { [Op.iLike]: "%" + query + "%" } },
          ],
        },
        raw: true,
      });
      if (result.length === 0) return JSON.stringify({ message: "no match" });
      else return JSON.stringify(result, null, 2);
    } catch (error) {
      console.error(error);
      return this.errorResponce;
    }
  }
}
