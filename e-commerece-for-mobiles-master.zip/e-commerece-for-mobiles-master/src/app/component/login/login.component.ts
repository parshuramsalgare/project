import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { ToastrService } from 'ngx-toastr';
import { LoginserviceService } from 'src/app/Service/loginservice.service';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.scss'],
})
export class LoginComponent implements OnInit {
  formOptions: Object = {
    submitMessage: '',
    disableAlerts: true,
    noAlerts: true,
  };

  id = localStorage.getItem('userID');
  loginData: any;

  constructor(
    public login: LoginserviceService,
    private router: Router,
    private toaster: ToastrService
  ) {
    this.loginData = this.login.jsonData;
  }

  ngOnInit(): void {}
  // login user
  onLogin(user: any) {
    this.login.loginService(user.data).subscribe((res: any) => {
      localStorage.setItem('name', res.firstName);
      console.log(res);
      localStorage.setItem('admin', res.role);
      if (res.status == 'success') {
        localStorage.setItem('userID', res.userId);
        this.toaster.success('', 'Login Successful');
        if (res.role == 'admin') {
          this.router.navigate(['/admin']).then(() => {
            window.location.reload();
          });
        } else if (res.role == 'user') {
          this.router.navigate(['/homepage']).then(() => {
            window.location.reload();
          });
        }
      } else {
        this.toaster.error('', 'Wrong Email or Password');
      }
    });
  }
}
