import { HttpClient } from '@angular/common/http';
import { Component, Input, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { ToastrService } from 'ngx-toastr';
import { LoginserviceService } from '../../Service/loginservice.service';
import { HomepageserviceService } from 'src/app/Service/homepageservice.service';

@Component({
  selector: 'app-homepage',
  templateUrl: './homepage.component.html',
  styleUrls: ['./homepage.component.scss'],
})
export class HomepageComponent implements OnInit {
  // hii
  admin = localStorage.getItem('admin');
  getSearchData: any = localStorage.getItem('search');
  productList: any[] = [];
  @Input() searchModel!: string;
  companyName: any;
  slide: boolean = true;
  allProduct: boolean = false;
  constructor(
    private http: HttpClient,
    public homepageservice: HomepageserviceService,
    public loginservice: LoginserviceService,
    private toaster: ToastrService,
    private router: Router
  ) {}
  product: any = [];
  ngOnInit(): void {
    // get All Company
    this.homepageservice.getAllCompany().subscribe((res) => {
      console.log(res);

      this.companyName = res;
    });
    // get All Product
    this.homepageservice.getAllProduct().subscribe((res) => {
      let pattern = new RegExp(this.getSearchData, 'i');
      this.product = res;
      console.log(this.product);
      // product searching
      if (this.getSearchData != null && this.getSearchData != '') {
        this.homepageservice
          .searchProduct(this.getSearchData)
          .subscribe((res: any) => {
            if (res.message == 'no match') {
              this.toaster.warning('', 'No search result found');
              localStorage.removeItem('search');
            } else {
              this.productList = res;
              this.slide = false;
              this.allProduct = true;
              this.detailcheck = true;
              localStorage.removeItem('search');
            }
          });
      }
    });
    this.addTocartid = this.loginservice.logoutId;
  }
  detail(data: any) {
    console.log(data);
  }
  // all products will be showed
  id: any;
  onProduct(id: any) {
    console.log(id);
    this.slide = false;
    this.allProduct = true;
    for (let i = 0; i < this.product.length; i++) {
      if (this.product[i].companyName == id) {
        this.productList.push(this.product[i]);
      }
    }
    this.ngOnInit();
  }
  // Add To Cart
  addTocartid: any;
  addtoCart(data: any, q: any) {
    let id: any = localStorage.getItem('userID');

    let formData = new FormData();
    formData.append('productId', data.id);
    formData.append('userId', this.addTocartid);
    if (id == null) {
      this.router.navigate(['/login']);
    } else {
      if (q.quantity > 0) {
        formData.append('quantity', q.quantity);
        console.log(formData);

        this.homepageservice.addtoCart(formData).subscribe((res: any) => {
          if (res.message == 'success') {
            this.toaster.success('', 'Product Added to Cart Successfully!');
          } else if (res.message == 'Insufficient stock') {
            this.toaster.error('', 'Insufficient stock');
          } else {
            this.toaster.error('', 'Something Went Wrong');
          }
        });
      }
    }
  }

  // Buy Product
  buyProduct(data: any) {
    let id: any = localStorage.getItem('userID');
    let formData = new FormData();
    formData.append('productId', data.id);
    formData.append('userId', id);
    formData.append('quantity', '1');
    if (id == null) {
      this.router.navigate(['/login']);
    } else {
      this.homepageservice.buyProduct(formData).subscribe((res: any) => {
        if (res.message == 'success') {
          this.toaster.success('', 'Product Purchased Successfully!');
        } else {
          this.toaster.error('', 'Something Went Wrong ');
        }
      });
    }
  }

  // product Details
  details: any[] = [];
  detailcheck: boolean = false;
  getDetail(data: any) {
    data.features = data.features.split(',');
    this.details.push(data);
    this.allProduct = false;
    this.detailcheck = true;
  }

  // Quantity of produtcs
  quantity: any;
  addQuantity(data: any) {
    console.log(data.quantity);
    this.quantity = data.quantity;
  }

  close() {
    this.allProduct = true;
    this.detailcheck = false;
    this.ngOnInit();
    this.details.pop();
  }

  // back page homepage
  back() {
    this.slide = true;
    this.allProduct = false;
    this.detailcheck = false;
    this.router.navigate(['/homepage']).then(() => {
      window.location.reload();
    });
  }
}
