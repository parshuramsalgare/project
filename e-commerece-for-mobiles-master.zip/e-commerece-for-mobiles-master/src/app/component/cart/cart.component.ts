import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { ToastrService } from 'ngx-toastr';
import { LoginserviceService } from '../../Service/loginservice.service';
import { CartserviceService } from 'src/app/Service/cartservice.service';

@Component({
  selector: 'app-cart',
  templateUrl: './cart.component.html',
  styleUrls: ['./cart.component.scss'],
})
export class CartComponent implements OnInit {
  totalCost: any;
  data: any[] = [];
  quantity: any;
  constructor(
    public cartservice: CartserviceService,
    public loginservice: LoginserviceService,
    private toaster: ToastrService,
    private router: Router
  ) {
    this.purchase(2);
  }
  ngOnInit(): void {
    this.cartservice.onCart(localStorage.getItem('userID')).subscribe((res) => {
      console.log(res);
      this.data = res.cartData;
      this.totalCost = res.totalCost[0].total;
    });
    // show empty cart if product is not available
    this.cartUserId = this.loginservice.logoutId;
    this.cartservice.emptyCart(this.cartUserId).subscribe((res: any) => {
      if (res.message == 'Empty cart') {
        this.empty = true;
        this.order = false;
      } else {
        this.cart = true;
        this.order = false;
      }
    });
  }
  // place the order from cart
  userId = localStorage.getItem('userID');
  placeorder(data: any) {
    let formData = new FormData();
    formData.append('userId', data);
    this.cartservice.placeorder(formData).subscribe((res: any) => {
      if (res.message == 'success') {
        this.toaster.success('', 'Order Placed Successfully!');
      } else {
        this.toaster.error('', 'Something Went Wrong ');
      }
      this.ngOnInit();
    });
  }
  // product remove from cart
  deleteProduct(data: any) {
    this.cartservice.delete(data).subscribe((res: any) => {
      if (res.message == 'success') {
        this.toaster.warning('', 'Product Removed From Cart');
      } else {
        this.toaster.error('', 'Something Went Wrong');
      }
      this.ngOnInit();
    });
  }
  // purchase the product from cart
  user: any = localStorage.getItem('userID');
  userData: any;
  purchase(id: any) {
    id = this.user;
    this.cart = false;
    this.empty = false;
    this.cartservice.purchase(id).subscribe((res: any[]) => {
      this.userData = res;
      res.forEach((element) => {
        if (element.product == null) {
          element.product = { model: 'null', price: 0 };
        }
        this.order = true;
      });
      this.ngOnInit();
    });
  }
  // back To homepage
  back() {
    this.router.navigate(['/homepage']).then(() => {
      window.location.reload();
    });
  }
  cartUserId: any;
  empty: boolean = false;
  cart: boolean = true;
  order: boolean = false;
}
