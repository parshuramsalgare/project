import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { ToastrService } from 'ngx-toastr';
import { SignupserviceService } from '../../Service/signupservice.service';

@Component({
  selector: 'app-signup',
  templateUrl: './signup.component.html',
  styleUrls: ['./signup.component.scss'],
})
export class SignupComponent implements OnInit {
  formOptions: Object = {
    submitMessage: '',
    disableAlerts: true,
    noAlerts: true,
  };
  signupData: any;
  constructor(
    public signup: SignupserviceService,
    private toaster: ToastrService,
    private router: Router
  ) {
    this.signupData = this.signup.jsonData;
  }

  ngOnInit(): void {}
  // signup user
  onSignup(users: any) {
    this.signup.signupService(users.data).subscribe((res: any) => {
      if (res.error == 'Already exist') {
        this.toaster.error('', 'Already exist');
      } else if (res.error == 'Cannot register as admin') {
        this.toaster.error('', 'Cannot register as admin');
      } else if (res.message == 'success') {
        this.toaster.success('', 'SignUp Successfully!');
      } else if (res.message == 'error') {
        this.toaster.error('', 'Add Correct Details');
      }
      this.router.navigate(['./login']);
    });
  }
}
