import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { CartserviceService } from 'src/app/Service/cartservice.service';
@Component({
  selector: 'app-previousorder',
  templateUrl: './previousorder.component.html',
  styleUrls: ['./previousorder.component.scss'],
})
export class PreviousorderComponent implements OnInit {
  constructor(public cartservice: CartserviceService, private router: Router) {}
  user: any = localStorage.getItem('userID');
  userData: any;
  ngOnInit(): void {
    // previous ordedrs of users
    this.cartservice.purchase(this.user).subscribe((res: any[]) => {
      this.userData = res;
      res.forEach((element) => {
        if (element.product == null) {
          element.product = { model: 'null', price: 0 };
        }
      });
      this.ngOnInit();
    });
  }
  // Back to homepage
  back() {
    this.router.navigate(['/homepage']).then(() => {
      window.location.reload();
    });
  }
}
