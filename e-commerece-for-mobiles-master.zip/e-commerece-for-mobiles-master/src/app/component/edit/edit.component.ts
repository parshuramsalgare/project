import { Component, Input, OnInit } from '@angular/core';
import { FormControl, FormGroup } from '@angular/forms';
import { ActivatedRoute, Router } from '@angular/router';
import { ToastrService } from 'ngx-toastr';
import { AdminserviceService } from '../../Service/adminservice.service';

@Component({
  selector: 'app-edit',
  templateUrl: './edit.component.html',
  styleUrls: ['./edit.component.scss'],
})
export class EditComponent implements OnInit {
  constructor(
    private router: ActivatedRoute,
    private adminservice: AdminserviceService,
    private route: Router,
    private toaster: ToastrService
  ) {}

  ngOnInit(): void {
    this.adminservice
      .updateData(this.router.snapshot.params['id'])
      .subscribe((result: any) => {
        // console.log(result);
        this.update = new FormGroup({
          model: new FormControl(result['model']),
          features: new FormControl(result['features']),
          price: new FormControl(result['price']),
          stock: new FormControl(result['stock']),
          titleimg: new FormControl(result['titleimg']),
        });
      });
  }
  update = new FormGroup({
    model: new FormControl(''),
    features: new FormControl(''),
    price: new FormControl(''),
    stock: new FormControl(''),
    titleimg: new FormControl(''),
  });
  //To Add images
  image: any;
  imageUpdate(event: any) {
    this.image = event.target.files[0];
  }
  // update the Data of product
  updateData() {
    console.log(this.update.value);
    let formData = new FormData();
    console.log(this.image.name);

    formData.append('titleimg', this.image, this.image.name);
    formData.append('id', this.router.snapshot.params['id']);
    formData.append('features', this.update.value.features);
    formData.append('price', this.update.value.price);
    formData.append('stock', this.update.value.stock);

    formData.append('model', this.update.value.model);
    this.adminservice.editData(formData).subscribe((res: any) => {
      if (res.message == 'update success') {
        this.toaster.success('', 'Product Updated Successfully!');
      } else {
        this.toaster.error('', 'Something Went Wrong');
      }
    });
    this.route.navigate(['/admin']);
    this.update.reset();
  }
}
