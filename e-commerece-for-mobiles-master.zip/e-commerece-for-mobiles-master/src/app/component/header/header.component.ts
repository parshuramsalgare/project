import { HttpClient } from '@angular/common/http';
import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { ToastrService } from 'ngx-toastr';
import { CartserviceService } from 'src/app/Service/cartservice.service';
import { LoginserviceService } from '../../Service/loginservice.service';

@Component({
  selector: 'app-header',
  templateUrl: './header.component.html',
  styleUrls: ['./header.component.scss'],
})
export class HeaderComponent implements OnInit {
  // role was stored in loaclstorage to verify who is logged in
  admin = localStorage.getItem('admin');
  // when user is logged in then name will be displayed
  name: any = localStorage.getItem('name');
  condition: boolean;
  userid: any = this.loginservice.logoutId;
  data: any[] = [];
  constructor(
    public carservice: CartserviceService,
    private router: Router,
    public loginservice: LoginserviceService,
    private toaster: ToastrService
  ) {
    this.loginData = this.loginservice.jsonData;

    this.condition = this.loginservice.login;
  }

  loginData: any;
  // serching product by users
  modelSearch: string = '';
  searchData() {
    localStorage.setItem('search', this.modelSearch);
    if (this.modelSearch != null && this.modelSearch != '') {
      this.router.navigate(['/homepage']).then(() => {
        window.location.reload();
      });
    }
  }

  cartQuantity: any;
  ngOnInit(): void {
    // show product quantity when users product added to cart
    this.carservice.onCart(localStorage.getItem('userID')).subscribe((res) => {
      this.cartQuantity = res.cartData.length;
      console.log(this.cartQuantity);
    });
    this.userid = localStorage.getItem('userID');
  }

  // logout User
  logout() {
    let id: any = localStorage.getItem('userID');
    if (id != null) {
      let formData = new FormData();
      formData.append('userId', id);

      this.loginservice.logOut(formData).subscribe((res: any) => {
        location.reload();
        if (res.message == 'success') {
          this.toaster.success('', 'Logout Successful!');
        } else {
          this.toaster.error('', 'Logout Failed!');
        }
        console.log(res);
      });
      localStorage.removeItem('userID');
      localStorage.removeItem('name');
      localStorage.removeItem('admin');
      this.router.navigate(['/login']);
    } else {
      this.toaster.warning('', 'Not Logged In');
    }
  }
}
