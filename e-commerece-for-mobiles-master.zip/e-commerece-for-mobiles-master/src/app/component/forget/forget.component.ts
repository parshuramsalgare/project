import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { ToastrService } from 'ngx-toastr';
import { ForgetserviceService } from '../../Service/forgetservice.service';

@Component({
  selector: 'app-forget',
  templateUrl: './forget.component.html',
  styleUrls: ['./forget.component.scss'],
})
export class ForgetComponent implements OnInit {
  formOptions: Object = {
    submitMessage: '',
    disableAlerts: true,
    noAlerts: true,
  };

  forgetData: any;
  constructor(
    public forgetservice: ForgetserviceService,
    private toaster: ToastrService,
    private router: Router
  ) {
    this.forgetData = this.forgetservice.forgetJsonData;
  }

  ngOnInit(): void {}
  //Call forget Password Api
  onForget(data: any) {
    this.forgetservice.onForget(data.data).subscribe((res: any) => {
      if (res.message == 'success') {
        this.toaster.success('', 'Password Updated Successfully!');
        this.router.navigate(['/login']);
      } else if (res.message == 'not registered') {
        this.toaster.warning('', 'You have not registered');
      } else {
        this.toaster.error('', 'Failed');
      }
    });
  }
}
