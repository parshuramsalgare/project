import { Component, OnInit } from '@angular/core';
import { NgForm } from '@angular/forms';
import { Router } from '@angular/router';
import { ToastrService } from 'ngx-toastr';
import { AdminserviceService } from 'src/app/Service/adminservice.service';
@Component({
  selector: 'app-admin',
  templateUrl: './admin.component.html',
  styleUrls: ['./admin.component.scss'],
})
export class AdminComponent implements OnInit {
  productDetails: any[] = [];
  constructor(
    public adminservice: AdminserviceService,
    private toaster: ToastrService,
    private router: Router
  ) {}
  ngOnInit(): void {
    // viewAll products
    this.adminservice.detail().subscribe((res: any) => {
      this.productDetails = res;
    });
  }
  // To add images by using form
  files: any;
  selectImage(event: any) {
    this.files = event.target.files[0];
  }
  // Add new product in stock
  addProduct(userdata: NgForm) {
    let formData = new FormData();
    formData.append('titleimg', this.files, this.files.name);
    formData.append('companyName', userdata.value.companyName);
    formData.append('features', userdata.value.features);
    formData.append('price', userdata.value.price);
    formData.append('stock', userdata.value.stock);
    formData.append('model', userdata.value.model);
    this.adminservice.addProduct(formData).subscribe((res: any) => {
      if (res.message == 'success') {
        this.toaster.success('', 'Product Added Successfully!');
      } else {
        this.toaster.error('', 'Failed');
      }
      this.ngOnInit();
    });
    userdata.resetForm();
  }
  // Delete Product from stock
  deleteProduct(data: any) {
    this.adminservice.deleteProduct(data).subscribe((res: any) => {
      if (res.message == 'success') {
        this.toaster.warning('', 'Product Deleted');
      } else {
        this.toaster.error('', 'Something Went Wrong');
      }
    });
  }
  // show all registered users
  showUser: boolean = false;
  users: any;
  viewAllUsers() {
    this.adminservice.getAllUsers().subscribe((res) => {
      this.users = res;
      console.log(this.users);
      this.showTable = false;
      this.showForm = false;
      this.showUser = true;
      this.showOrder = false;
    });
  }
  // All Orders of users
  showOrder: boolean = false;
  order: any;
  viewOrder() {
    this.adminservice.viewOrder().subscribe((res) => {
      this.order = res;
      this.order.forEach((element: any) => {
        if (element.product == null) {
          element.product = { model: 'null', price: 0 };
        }
      });
      this.showOrder = true;
      this.showTable = false;
      this.showForm = false;
      this.showUser = false;
    });
  }

  // show table of all products
  showTable: boolean = false;
  showForm: boolean = false;
  viewTable() {
    this.showTable = true;
    this.showForm = false;
    this.showUser = false;
    this.showOrder = false;
  }
  // showForm of add products
  viewForm() {
    this.showTable = false;
    this.showForm = true;
    this.showUser = false;
    this.showOrder = false;
  }

  // back To homepage
  back() {
    this.router.navigate(['/homepage']).then(() => {
      window.location.reload();
    });
  }
}
