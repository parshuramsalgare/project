import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';

@Injectable({
  providedIn: 'root',
})
export class SignupserviceService {
  constructor(private http: HttpClient) {}
  jsonData: Object = {
    components: [
      {
        label: 'FirstName',
        placeholder: 'Enter firstname',
        tableView: true,
        validate: {
          required: true,
          minLength: 3,
          maxLength: 10,
          minWords: 1,
        },
        key: 'firstName',
        type: 'textfield',
        input: true,
      },
      {
        label: 'LastName',
        placeholder: 'Enter lastname',
        tableView: true,
        validate: {
          required: true,
          minLength: 3,
          maxLength: 10,
          minWords: 1,
        },
        key: 'lastName',
        type: 'textfield',
        input: true,
      },
      {
        label: 'Email',
        placeholder: 'Enter Email',
        tableView: true,
        validate: {
          required: true,
          minLength: 10,
          maxLength: 30,
        },
        key: 'email',
        type: 'email',
        input: true,
      },
      {
        label: 'Password',
        mask: true,
        placeholder: 'Enter Password',
        tableView: true,
        validate: {
          required: true,
          minLength: 3,
          maxLength: 10,
        },
        key: 'password',
        type: 'textfield',
        input: true,
      },
      {
        label: 'Role',
        widget: 'html5',
        tableView: true,
        data: {
          values: [
            {
              label: 'admin',
              value: 'admin',
            },
            {
              label: 'user',
              value: 'user',
            },
          ],
        },
        key: 'role',
        type: 'select',
        input: true,
      },
      {
        label: 'Register',
        showValidations: false,
        tableView: false,
        key: 'submit',
        customClass: 'mt-2',
        type: 'button',
        input: true,
        saveOnEnter: false,
      },
    ],
  };

  signupService(newuser: object) {
    return this.http.post<any>(
      'http://localhost:4200/api/user/register',
      newuser
    );
  }
}
