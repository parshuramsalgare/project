import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root',
})
export class AdminserviceService {
  constructor(private http: HttpClient) {}
  // show All Company
  url: any = 'http://localhost:4200/api';
  allCompany() {
    return this.http.get<any>(`${this.url}/get/all/company`);
  }
  // Add Product
  addProduct(product: object) {
    return this.http.post<any>(`${this.url}/add/product`, product);
  }
  //
  detail() {
    return this.http.get(`${this.url}/get/all/product`);
  }
  updateData(id: any) {
    return this.http.get(`${this.url}/get/product/${id}`);
  }

  editData(data: any) {
    return this.http.put(`${this.url}/update/product`, data);
  }

  deleteProduct(id: any) {
    return this.http.delete(`${this.url}/delete/product/${id}`);
  }

  getAllUsers() {
    return this.http.get(`${this.url}/get/all/user`);
  }

  viewOrder() {
    return this.http.get(`${this.url}/get/all/purchased`);
  }

  viewCompany() {
    return this.http.get(`${this.url}/get/all/company`);
  }

  addCompany(data: any) {
    return this.http.post(`${this.url}/add/company`, data);
  }

  deleteCompany(id: any) {
    return this.http.delete(`${this.url}/delete/company/${id}`);
  }
}
