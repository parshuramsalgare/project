import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { BehaviorSubject } from 'rxjs';

@Injectable({
  providedIn: 'root',
})
export class CartserviceService {
  cartItemList: any = [];
  productList = new BehaviorSubject<any>([]);
  constructor(private http: HttpClient) {}
  url = 'http://localhost:4200/api';
  onCart(id: any) {
    return this.http.get<any>(`${this.url}/product/cart/get/${id}`);
  }
  // placeorder
  placeorder(data: any) {
    return this.http.post(`${this.url}/product/placeorder`, data);
  }
  delete(id: any) {
    return this.http.delete(`${this.url}/product/removefromcart/${id}`);
  }
  purchase(id: any) {
    return this.http.get<any>(`${this.url}/get/all/purchased/${id}`);
  }
  emptyCart(id: any) {
    return this.http.get(`${this.url}/product/cart/get/${id}`);
  }
}
