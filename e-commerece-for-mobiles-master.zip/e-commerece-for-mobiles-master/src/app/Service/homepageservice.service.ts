import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { HttpParams } from '@angular/common/http';
@Injectable({
  providedIn: 'root',
})
export class HomepageserviceService {
  constructor(private http: HttpClient) {}
  // url to call api
  url: any = 'http://localhost:4200/api';
  // addtocart method is used to add product in cart
  addtoCart(data: object) {
    return this.http.post(`${this.url}/product/addtocart`, data);
  }
  // this method is used to buy product
  buyProduct(data: any) {
    return this.http.post(`${this.url}/product/buy`, data);
  }
  // this method is used to get all company name
  getAllCompany() {
    return this.http.get(`${this.url}/get/all/company`);
  }
  // this method is used to get all product
  getAllProduct() {
    return this.http.get(`${this.url}/get/all/product`);
  }
  // this method is used to search product
  searchProduct(data: any) {
    return this.http.get(`${this.url}/search?keyword=${data}`);
  }
}
