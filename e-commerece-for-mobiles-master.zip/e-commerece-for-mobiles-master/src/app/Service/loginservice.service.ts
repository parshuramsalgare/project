import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root',
})
export class LoginserviceService {
  // to hide button of login and logout
  logoutId = localStorage.getItem('userID');
  login!: boolean;
  constructor(private http: HttpClient) {
    console.log(this.logoutId);
    if (this.logoutId != null) {
      this.login = false;
      console.log(this.login);
    } else {
      this.login = true;
      console.log(this.login);
    }
  }
  // Login Form json data
  jsonData: Object = {
    components: [
      {
        label: 'Email',
        placeholder: 'Enter Email',
        tableView: true,
        validate: {
          required: true,
        },
        key: 'email',
        type: 'textfield',
        input: true,
      },
      {
        label: 'Password',
        mask: true,
        placeholder: 'Enter Password',
        tableView: true,
        validate: {
          required: true,
          minLength: 8,
          maxLength: 20,
        },
        key: 'password',
        type: 'textfield',
        input: true,
      },
      {
        label: 'HTML',
        tag: 'a',
        className: 'text-white ',

        attrs: [
          {
            attr: 'href',
            value: 'forget',
          },
        ],
        content: 'Forgot password?',
        refreshOnChange: false,
        customClass: 'mt-2 ',
        key: 'html',
        type: 'htmlelement',
        input: false,
        tableView: false,
      },
      {
        label: 'Login',
        showValidations: false,
        tableView: false,
        key: 'submit',
        customClass: 'mt-2',
        type: 'button',
        input: true,
        saveOnEnter: false,
      },
    ],
  };
  url: any = 'http://localhost:4200/api';
  loginService(newuser: any) {
    return this.http.post<any>(`${this.url}/login`, newuser);
  }
  logOut(user: object) {
    return this.http.post<any>(`${this.url}/logout`, user);
  }
}
