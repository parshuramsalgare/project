import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root',
})
export class ForgetserviceService {
  constructor(private http: HttpClient) {}
  // Forget Password
  forgetJsonData: Object = {
    components: [
      {
        label: 'Email',
        placeholder: 'Enter Registered Email',
        tableView: true,
        validate: {
          required: true,
        },
        unique: true,
        key: 'email',
        type: 'email',
        input: true,
      },
      {
        label: 'Create New Password',
        mask: true,
        placeholder: 'Enter Password',
        tableView: false,
        validate: {
          required: true,
          minLength: 8,
        },
        key: 'password',
        type: 'password',
        input: true,
        protected: true,
      },

      {
        label: 'Submit',
        showValidations: false,
        tableView: false,
        customClass: 'mt-2',
        key: 'submit',
        type: 'button',
        input: true,
        saveOnEnter: false,
      },
    ],
  };

  // forget password
  onForget(newuser: any) {
    return this.http.put<any>(
      'http://localhost:4200/api/user/resetpassword',
      newuser
    );
  }
}
